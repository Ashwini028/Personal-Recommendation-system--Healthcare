import networkx as nx


class GraphRecommender:
    def __init__(self):
        self.graph = nx.Graph()

    def add_interaction(self, user, item):
        self.graph.add_node(user, type="user")
        self.graph.add_node(item, type="item")
        self.graph.add_edge(user, item)

    def recommend(self, user, top_k=5):
        if user not in self.graph:
            return []

        neighbors = list(self.graph.neighbors(user))
        scores = {}
        for item in neighbors:
            for neighbor in self.graph.neighbors(item):
                if neighbor != user and self.graph.nodes[neighbor].get("type") == "item":
                    scores[neighbor] = scores.get(neighbor, 0) + 1

        ranked_items = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        return [item for item, _ in ranked_items[:top_k]]

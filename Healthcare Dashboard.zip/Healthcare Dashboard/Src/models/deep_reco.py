import numpy as np
import tensorflow as tf
import tensorflow.keras.models
from tensorflow.keras.layers import Input, Embedding, Flatten, Dense, Concatenate


class DeepRecommender:
    def __init__(self, num_users, num_items, embedding_dim=50):
        self.num_users = num_users
        self.num_items = num_items
        self.embedding_dim = embedding_dim
        self.model = self._build_model()

    def _build_model(self):
        user_input = Input(shape=(1,), name="user")
        item_input = Input(shape=(1,), name="item")

        user_embedding = Embedding(self.num_users, self.embedding_dim, name="user_emb")(user_input)
        item_embedding = Embedding(self.num_items, self.embedding_dim, name="item_emb")(item_input)

        user_vec = Flatten(name="user_vec")(user_embedding)
        item_vec = Flatten(name="item_vec")(item_embedding)

        concat = Concatenate(name="concat")([user_vec, item_vec])
        hidden = Dense(128, activation="relu")(concat)
        hidden = Dense(64, activation="relu")(hidden)
        output = Dense(1, activation="sigmoid")(hidden)

        model = Model(inputs=[user_input, item_input], outputs=output)
        model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
        return model

    def train(self, user_ids, item_ids, labels, epochs=5, batch_size=32):
        self.model.fit([user_ids, item_ids], labels, epochs=epochs, batch_size=batch_size, verbose=1)

    def predict(self, user_id, item_id):
        return float(self.model.predict([np.array([user_id]), np.array([item_id])], verbose=0)[0][0])

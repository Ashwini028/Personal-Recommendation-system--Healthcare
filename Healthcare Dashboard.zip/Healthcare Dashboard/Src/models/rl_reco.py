import numpy as np
import random


class RLRecommender:
    def __init__(self, num_items, epsilon=0.1, alpha=0.1, gamma=0.9):
        self.num_items = num_items
        self.q_table = np.zeros(num_items)  # Q-values for each item
        self.epsilon = epsilon  # exploration rate
        self.alpha = alpha      # learning rate
        self.gamma = gamma      # discount factor

    def select_item(self):
        if random.random() < self.epsilon:
            return random.randint(0, self.num_items - 1)  # Explore
        else:
            return int(np.argmax(self.q_table))  # Exploit

    def update(self, action, reward):
        best_future = np.max(self.q_table)
        self.q_table[action] = self.q_table[action] + self.alpha * (
            reward + self.gamma * best_future - self.q_table[action]
        )

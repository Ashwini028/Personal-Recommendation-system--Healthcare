import re
import nltk
from sklearn.feature_extraction.text import TfidfVectorizer
from textblob import TextBlob

# Ensure stopwords are available
try:
    from nltk.corpus import stopwords
    _ = stopwords.words("english")
except LookupError:
    nltk.download("stopwords")
    from nltk.corpus import stopwords


class TextProcessor:
    def __init__(self):
        self.stop_words = set(stopwords.words("english"))
        self.vectorizer = TfidfVectorizer(max_features=5000)

    def clean_text(self, text: str) -> str:
        text = text.lower()
        text = re.sub(r"[^a-z\s]", "", text)
        tokens = [word for word in text.split() if word not in self.stop_words]
        return " ".join(tokens)

    def get_sentiment(self, text: str) -> float:
        """Returns sentiment polarity between -1 (negative) and +1 (positive)."""
        return TextBlob(text).sentiment.polarity

    def fit_transform(self, texts):
        clean_texts = [self.clean_text(t) for t in texts]
        return self.vectorizer.fit_transform(clean_texts)

    def transform(self, texts):
        clean_texts = [self.clean_text(t) for t in texts]
        return self.vectorizer.transform(clean_texts)

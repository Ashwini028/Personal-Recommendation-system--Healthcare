import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

st.set_page_config(page_title="Healthcare Dashboard & Reporting", layout="wide")

# ----------------- Load Data -----------------
@st.cache_data
def load_data(path: str):
    df = pd.read_csv("D:\Healthcare Dashboard\healthcare_dataset.csv")
    for c in ["Date of Admission","Discharge Date"]:
        if c in df.columns:
            df[c] = pd.to_datetime(df[c], errors="coerce")
    for c in ["Age","Billing Amount","Room Number"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    if "Date of Admission" in df.columns and "Discharge Date" in df.columns:
        df["LOS_Days"] = (df["Discharge Date"] - df["Date of Admission"]).dt.days
    if "Date of Admission" in df.columns:
        df["Admission_Date"] = df["Date of Admission"].dt.date
    return df

def bar_chart(series, xlabel, ylabel, title, rotate=45):
    fig, ax = plt.subplots()
    series.plot(kind="bar", ax=ax)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.set_title(title)
    ax.tick_params(axis="x", rotation=rotate)
    st.pyplot(fig)

def line_chart(series, xlabel, ylabel, title):
    fig, ax = plt.subplots()
    series.plot(ax=ax)
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.set_title(title)
    st.pyplot(fig)

# ----------------- Sidebar -----------------
st.sidebar.header("Settings")
data_path = st.sidebar.text_input("CSV Path", value="healthcare_dataset.csv")

try:
    df = load_data(data_path)
except Exception as e:
    st.error(f"Could not load dataset: {e}")
    st.stop()

# ----------------- Tabs -----------------
tabs = st.tabs([ 
    "🏠 Overview",
    "📈 Admissions & Revenue",
    "🩺 Conditions & Medications",
    "📤 Reporting & Exports"
])

# ---- Overview ----
with tabs[0]:
    st.title("🏥 Healthcare Dashboard")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Patients", len(df))
    c2.metric("Revenue", f"{df['Billing Amount'].sum():,.0f}" if "Billing Amount" in df else 0)
    c3.metric("Avg LOS", f"{df['LOS_Days'].mean():.2f}" if "LOS_Days" in df else "—")
    c4.metric("Unique Conditions", df["Medical Condition"].nunique() if "Medical Condition" in df else 0)
    st.dataframe(df.head(100), use_container_width=True)

# ---- Admissions & Revenue ----
with tabs[1]:
    st.subheader("Admissions & Revenue Trends")
    if "Admission_Date" in df.columns:
        daily = df.groupby("Admission_Date").agg(
            admissions=("Admission_Date","count"),
            revenue=("Billing Amount","sum")
        ).sort_index()
        st.markdown("**Daily Admissions**")
        line_chart(daily["admissions"], "Date", "Admissions", "Admissions Over Time")
        st.markdown("**Daily Revenue**")
        line_chart(daily["revenue"], "Date", "Revenue", "Revenue Over Time")

# ---- Conditions & Medications ----
with tabs[2]:
    st.subheader("Top Conditions & Medications")
    if "Medical Condition" in df.columns:
        topc = df["Medical Condition"].value_counts().head(15)
        bar_chart(topc, "Condition", "Count", "Top Conditions")
    if "Medication" in df.columns:
        topm = df["Medication"].value_counts().head(15)
        bar_chart(topm, "Medication", "Count", "Top Medications")

# ---- Reporting ----
with tabs[3]:
    st.subheader("Exports")
    if "Medical Condition" in df.columns:
        cond = df["Medical Condition"].value_counts().rename_axis("Condition").reset_index(name="Count")
        st.download_button("Download Top Conditions", data=cond.to_csv(index=False).encode(), file_name="top_conditions.csv")
    if "Medication" in df.columns:
        meds = df["Medication"].value_counts().rename_axis("Medication").reset_index(name="Count")
        st.download_button("Download Top Medications", data=meds.to_csv(index=False).encode(), file_name="top_medications.csv")
    st.download_button("Download Full Dataset", data=df.to_csv(index=False).encode(), file_name="dataset.csv")
